

struct solution{
  int *tour;
  int id;
  double tour_length;
  int steps;
};


extern solution *random_sol;


void initialize_random_heuristic();
void generate_random_solution();
void print_tour(solution *s);
void check_tour(solution *s);



void free_heuristic();