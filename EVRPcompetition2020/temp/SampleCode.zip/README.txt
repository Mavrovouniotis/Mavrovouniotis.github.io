EVRP.cpp EVRP.hpp
Implementation of the electric vehicle routing. The functions in this class can be used in your implementation

stats.cpp stats.hpp
Implementation to store the best solution for the 20 RUNS. The functions in this class can be used in your implementation to store the results in the output files

heuristic.cpp heuristic.hpp
Sample code of a heuristic that generates a solution randomly

main.cpp 
Executable of the source code