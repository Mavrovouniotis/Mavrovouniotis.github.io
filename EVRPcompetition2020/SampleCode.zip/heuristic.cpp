#include<cmath>
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<cstring>
#include<math.h>
#include<fstream>
#include<limits.h>

#include "heuristic.hpp"
#include "EVRP.hpp"

using namespace std;


solution *random_sol;   //random solution

/*initialize the structure of the random heuristic*/
void initialize_random_heuristic(){

    random_sol = new solution;
    random_sol->tour = new int[NUM_OF_CUSTOMERS+1000];
    random_sol->id = 1;
    random_sol->steps = 0;
    random_sol->tour_length = INT_MAX;
}

/*generate a random solution for the random heuristic*/
void generate_random_solution(){
  
  int i,help, object, tot_assigned =0;
  int *r;
  double energy_temp = 0.0; 
  double capacity_temp = 0.0;
  int from, to, temp;
  int charging_station;
  
  r = new int[NUM_OF_CUSTOMERS+1];
  //set indexes of objects
  for(i = 1; i <= NUM_OF_CUSTOMERS; i++){
    r[i-1]=i;

  }
  //randomly change indexes of objects
  for(i = 0; i <= NUM_OF_CUSTOMERS; i++){
    object = (int) ((rand()/(RAND_MAX+1.0)) * (double)(NUM_OF_CUSTOMERS-tot_assigned));
    help = r[i];
    r[i]=r[i+object];
    r[i+object]=help;
    tot_assigned++;
  }

  random_sol->steps = 0;
  random_sol->tour_length = INT_MAX;
  
  random_sol->tour[0] = DEPOT;
  random_sol->steps++;

  i = 0;
  while(i < NUM_OF_CUSTOMERS) {
    from = random_sol->tour[random_sol->steps-1];
    to = r[i];
    if((capacity_temp + get_customer_demand(to)) <= MAX_CAPACITY && energy_temp+get_energy_consumption(from,to) <= BATTERY_CAPACITY){
        capacity_temp  += get_customer_demand(to);
        energy_temp += get_energy_consumption(from,to);
        random_sol->tour[random_sol->steps] = to;
        random_sol->steps++;
        i++;
    } else if ((capacity_temp + get_customer_demand(to)) > MAX_CAPACITY){
        capacity_temp = 0.0;
        energy_temp = 0.0;
        random_sol->tour[random_sol->steps] = DEPOT;
        random_sol->steps++;
    } else if (energy_temp+get_energy_consumption(from,to) > BATTERY_CAPACITY){
       charging_station = rand() % (ACTUAL_PROBLEM_SIZE-NUM_OF_CUSTOMERS)+NUM_OF_CUSTOMERS+1;
       if(is_charging_station(charging_station)==true){
          energy_temp = 0.0;
          random_sol->tour[random_sol->steps] =  charging_station;
          random_sol->steps++;
        }
    } else {
        capacity_temp = 0.0;
        energy_temp = 0.0;
        random_sol->tour[random_sol->steps] =  DEPOT;
        random_sol->steps++;
    }
   
  }
 
  //close EVRP tour to return back to the depot
  if(random_sol->tour[random_sol->steps-1]!=DEPOT){
    random_sol->tour[random_sol->steps] = DEPOT;
    random_sol->steps++;
  }


  random_sol->tour_length = fitness_evaluation(random_sol->tour, random_sol->steps);


  //free memory
  delete[] r;
}



/*print solution*/
void print_tour(solution *s) {
    int   i;

    for( i = 0 ; i < s->steps; i++ ) {
         cout << s->tour[i] <<  " , ";
    }
    cout << "\ntour length = " << s->tour_length <<  endl;
    cout << "# of steps = " << s->steps << endl; 

}


/*validate solution*/
void check_tour(solution *s){
  int i, from, to;
  double energy_temp = BATTERY_CAPACITY; 
  double capacity_temp = MAX_CAPACITY;
  double distance_temp = 0.0;

  for(i = 0; i < s->steps-1; i++){
    from = s->tour[i];
    to = s->tour[i+1];
    capacity_temp -= get_customer_demand(to);
    energy_temp -= get_energy_consumption(from,to);
    distance_temp += get_distance(from,to);
    if(capacity_temp < 0.0) {
      cout << "error: capacity below 0 at customer " << to <<  endl;
     
    }
    if(energy_temp < 0.0) {
       cout << "error: energy below 0 from " << from << " to " << to <<  endl;
    }
    if(to == DEPOT) {
      capacity_temp = MAX_CAPACITY;
    }
    if(is_charging_station(to)==true || to==DEPOT){
      energy_temp = BATTERY_CAPACITY;
    }
  }
  if(distance_temp != s->tour_length) {
    cout << "error: check fitness evaluation" << endl;
  }
}


/*free memory structures*/
void free_heuristic(){

  delete[] random_sol->tour;


}

