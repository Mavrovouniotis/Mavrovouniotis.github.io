/**************************************************************************************/
/* ACODBGP.c                   TSP version 1.0                                        */
/* This is an implementation of the dynamic benchmark generator for permutation       */
/* encoded problems (DBGP) of the following paper:                                    */
/*                                                                                    */
/*   M. Mavrovouniotis, S. Yang and X. Yao. A benchmark generator for dynamic         */
/*   permutation-encoded problems. Proceedings of the 12th International Conference on*/ 
/*   Parallel Problem Solving from Nature (PPSN XII), Part II, LNCS, vol. 7492, pp.   */
/*   508-517, Springer-Verlag, 2012.                                                  */
/*                                                                                    */
/* Compile:                                                                           */
/*   g++ -o DBGPTSP DBGPTSP.c                                                         */
/* Run:                                                                               */
/*   ./DBGPTSP problem_instance change_degree change_speed                            */
/*                                                                                    */
/*   e.g., ./DBGPTSP eil51.tsp 0.25 100                                               */
/*                                                                                    */
/* Written by:                                                                        */
/*   Michalis Mavrovouniotis, De Montfort University, UK; July 2013                   */
/*                                                                                    */
/* If any query, please email Michalis Mavrovouniotis at mmavrovouniotis@dmu.ac.uk    */ 
/*                                                                                    */
/**************************************************************************************/

#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<string>
#include<cstring>
#include<math.h>
#include<fstream>
#include<cmath>
#include<time.h>
#include<limits.h>

using namespace std;

#define CHAR_LEN 100
#define MAX_RUNS 30
#define MAX_EVALUATIONS 100000
#define SAMPLING 100

/*DO NOT CHANGE ANY OF THE METHODS OF THE DBGP*/

struct object { 
  int id;
  double x;
  double y;
};

struct object *init_objects;     //Actual objects of the instance
struct object *masked_objects;   //Masked objects of the instance
int **distances;                 //Distance matrix
int problem_size;                //Size of the instance
char* problem_instance;          //Name of the instance

double change_degree;            //Ratio of swapped objects
int change_speed;                //Peiord of changes in algorithmic iterations

int* random_vector;              //Mask of random objects
int* re_random_vector;           //Mask of re-ordered random objects

int current_iteration;           //Used to calculate the period of change
int seed;                        //Random seed for algorithms
int evaluations;
int num_change;
double perf;
double* perf_of_trials;
double best_after_change;

//Used to output offline performance and population diversity
FILE *log_performance;
//output files
char * perf_filename; 


/****************************************************************/
/*Random number generator where the seed is the same in all runs*/
/****************************************************************/
double env_random_number(double low, double high) {
  return ((double)(rand()%10000)/10000.0)*(high - low) + low;  
}

/****************************************************************/
/*Generate a vector of random objects used for the swaps        */
/****************************************************************/
int * generate_random_vector(int size){
  int i, help, node, tot_assigned = 0;
  double rnd;
  int  *r;
  r = new int[size];
  //input object indexes
  for ( i = 0 ; i < size; i++){
    r[i] = i;
  } 
  for ( i = 0 ; i < size ; i++ ) {
    //find an index for a object randomly 
    rnd  = env_random_number(0.0,1.0);
    node = (int) (rnd  * (size - tot_assigned));//random number 
    help = r[i];
    r[i] = r[i+node];
    r[i+node] = help;
    tot_assigned++;
  }
  return r;
}

/****************************************************************/
/*Re-order the first random objects vector to swap objects      */
/*according to the degree of change                             */
/****************************************************************/
int * generate_reordered_random_vector(){
  int i, changes, help, r_index;
  int *r;  
  //set swaps on the first "changes" objects
  changes = (int)abs(change_degree * problem_size);
  r = new int[changes];
  //input object indexes
  for (i = 0; i < changes; i++){
    r[i] = random_vector[i];
  }
  //re-order the random_vector randomly
  for (i = 0; i < changes; i++){
    help = r[i];   
    r_index = (int)(env_random_number(0.0,1.0) * (double)changes);//random number 0..changes
    r[i] = r[r_index];
    r[r_index] = help;
  }
  return r;
}

/****************************************************************/
/*Compute and return the euclidean distance of two objects      */
/****************************************************************/
int euclidean_distance(int i, int j) {
  double xd,yd;
  int r = 0;
  xd = masked_objects[i].x - masked_objects[j].x;
  yd = masked_objects[i].y - masked_objects[j].y;
  r  = sqrt(xd*xd + yd*yd) + 0.5; 
  return r;
}

/****************************************************************/
/*Compute the distance matrix of the problem instance           */
/****************************************************************/
void compute_distances(void) {
  for(int i = 0; i <problem_size; i++){
    for(int j = 0; j < problem_size; j++){
      distances[i][j] = euclidean_distance(i,j);    
    }
  }
}

/****************************************************************/
/*Swap the location between two objects of the problem instance */
/****************************************************************/
void swap_masked_objects(int obj1, int obj2){
  double help1, help2;  
  help1=help2 = 0.0; 
  help1 = masked_objects[obj1].x;
  help2 = masked_objects[obj1].y; 
  masked_objects[obj1].x = masked_objects[obj2].x;
  masked_objects[obj1].y = masked_objects[obj2].y;  
  masked_objects[obj2].x = help1;
  masked_objects[obj2].y = help2;
}

/****************************************************************/
/* Perform random changes by swapping the first                 */
/* (change_degree * problem_size) objects randomly              */
/****************************************************************/
void add_random_change(void){
  int i, changes,  obj1, obj2; 
  changes = (int)abs(change_degree * problem_size);
  random_vector = generate_random_vector(problem_size);
  re_random_vector = generate_reordered_random_vector(); 
  //swap locations of objects
  for (i = 0; i < changes; i++){
    obj1 = masked_objects[random_vector[i]].id;
    obj2 = masked_objects[re_random_vector[i]].id;
    swap_masked_objects(obj1, obj2);    
  }
}

/****************************************************************/
/* Remove the previously object swaps and returns the problem   */
/* instance to its initial state. Hence, the dynamic changes    */ 
/* are not incremental                                          */
/****************************************************************/
void reverse_changes(){
   int i, obj1, obj2; 
  //reverse swapped objects         
  int changes = (int)abs(change_degree * problem_size);
  for (i = changes - 1; i >= 0; i--){
    obj1 = masked_objects[re_random_vector[i]].id;
    obj2 = masked_objects[random_vector[i]].id;    
    swap_masked_objects(obj1, obj2);
  }
}

/****************************************************************/
/*Generate and return a two-dimension array of type int         */
/****************************************************************/
int ** generate_2D_matrix_int(int n, int m){
  int **matrix;
  matrix = new int*[n];
  for ( int i = 0 ; i < n ; i++ ) {
    matrix[i] = new int[m];
  }
  //initialize 2-d array
  for(int i = 0; i < n; i++){
    for(int j = 0; j < m; j++) {
      matrix[i][j] = 0;
    }
  }
  return matrix;
}

/****************************************************************/
/* Read the problem instance and generate the initial object    */
/* vector.                                                      */
/****************************************************************/
void read_problem(char* filename){
  char line[CHAR_LEN];
  char * keywords;
  char Delimiters[] = " :=\n\t\r\f\v";
  ifstream fin(filename);
  while((fin.getline(line, CHAR_LEN-1))){
    if(!(keywords = strtok(line, Delimiters)))
      continue;
    if(!strcmp(keywords, "DIMENSION")){			
      if(!sscanf(strtok(NULL, Delimiters), "%d", &problem_size)){
	cout<<"DIMENSION error"<<endl;
	exit(0);
      }
    }
    else if(!strcmp(keywords, "EDGE_WEIGHT_TYPE")){
      char * tempChar;
      if(!(tempChar=strtok(NULL, Delimiters))){
	cout<<"EDGE_WEIGHT_TYPE error"<<endl;
	exit(0);
      }
      if(strcmp(tempChar, "EUC_2D")){
	cout<<"not EUC_2D"<<endl;
	exit(0);
      }
    }
    else if(!strcmp(keywords, "NODE_COORD_SECTION")){
      if(problem_size!=0){
      masked_objects = new object[problem_size];
      init_objects = new object[problem_size];
      int i;
      for(i=0; i<problem_size; i++){
	//store initial objects
        fin>>init_objects[i].id;       
	fin>>init_objects[i].x>>init_objects[i].y;
        init_objects[i].id -=1;
	//initialize masked_objects with initial objects
        masked_objects[i].x=init_objects[i].x;
        masked_objects[i].y=init_objects[i].y;
        masked_objects[i].id=init_objects[i].id;
      }
      //compute the distances using initial objects
       distances = generate_2D_matrix_int(problem_size, problem_size);
       compute_distances();
     }
    }
  }
  fin.close();
}

/****************************************************************/
/* Initialize the environment with the initial objects and      */ 
/* perform the initial dynamic change/generate base states      */
/****************************************************************/
void initialize_environment(){
  //initialize masked_objects with initial objects
  for(int i = 0; i < problem_size; i++) {
   masked_objects[i].x = init_objects[i].x;
   masked_objects[i].y = init_objects[i].y;
   masked_objects[i].id = init_objects[i].id;
  }
  add_random_change(); 
  compute_distances();
}

/****************************************************************/
/* Perform the dynamic change every "period" iteration, i.e.,   */ 
/* swapping objects                                             */
/****************************************************************/
void change_environment(){
   reverse_changes();
   add_random_change();    
   compute_distances();
}

/****************************************************************/
/* Validate the values input by the user                        */
/****************************************************************/
void check_input_parameters() {

 if(problem_size == 0) {
   cout << "wrong problem instance file" << endl;
   exit(2);
 }
 if(change_degree > 1.0 || change_degree <= 0.0) {
   cout << "select a valid change degree (between 0..1)" << endl;
   exit(2);
 }
 if(change_speed <= 0) {
   cout << "select a valid change speed (int)" << endl;
   exit(2);
 }
}

/****************************************************************/
/* Evaluate a TSP tour and return the length. This method can   */
/* be used in the optimizer integrated with DBGP. The TSP tour  */
/* to input is an array of integers, where each integer         */
/* corresponds to an object                                     */
/****************************************************************/
int fitness_evaluation(int *t) {
  int i, tour_length = 0;
  for (i = 0 ; i < problem_size; i++ ) {
    tour_length += distances[t[i]][t[i+1]];
  }
  evaluations++;
  if(evaluations%SAMPLING==0){ 
   if(best_after_change == 0) { 
     best_after_change = tour_length;
   }
   perf += best_after_change;
  }
  return tour_length;
}
/*************************************END OF DBGP**************************************/

 

/*******************EXAMPLE OF AN ACO IMPLEMENTATION***********************************/ 
/**************************************************************************************/      
/*                                                                                    */
/*  The Ant System algorithm is based on the original ACO framework implementation:   */ 
/*                                                                                    */
/*    Thomas Stuetzle. ACOTSP, Version 1.02. Available from                           */
/*    http://www.aco-metaheuristic.org/aco-code, 2004.                                */           
/*                                                                                    */
/* Written by:                                                                        */
/*   Michalis Mavrovouniotis, De Montfort University, UK; refined July 2013           */
/*                                                                                    */
/* If any query, please email Michalis Mavrovouniotis at mmavrovouniotis@dmu.ac.uk    */ 
/*                                                                                    */
/**************************************************************************************/

#define IA       16807
#define IM       2147483647
#define AM       (1.0/IM)
#define IQ       127773
#define IR       2836
#define MASK     123459876
#define EPSILON  0.000000000000000000000001
#define INFTY    INT_MAX

//Ant or individual structure that represent the TSP tour and tour cost
struct ant{
  int *tour;
  bool *visited;
  int tour_length;
};

struct ant *ant_population;   //Population of ants or individuals
ant *best_so_far_ant;         //current best so far tour 

double **pheromone;           //Pheromone matrix
double **heuristic;           //Heuristic information matrix
double **total;               //Pheromone + Heuristic information matrix

double *prob_of_selection;    //Selection probabilities

//General ACO parameters 
double alpha;
double beta;
double q_0;
double trail0;
double rho;

int n_ants;                  //Population size
int depth;                   //Candidate list size (nearest neighbour)
int **nn_list;               //Candidate lists

/****************************************************************/
/*                     Initialization                           */
/****************************************************************/
void set_algorithm_parameters(void){
  //change the algorithm parameters according to your needs
  alpha = 1;
  beta = 5;
  q_0 = 0.0;
  rho = 0.6;
  n_ants = 50;
  depth = 20;
}

void allocate_ants(void){
  int i;  

  ant_population = new ant[n_ants];
  for(i = 0; i < n_ants; i++){
    ant_population[i].tour = new int[problem_size+1];
    ant_population[i].visited = new bool[problem_size];
  }
  best_so_far_ant = new ant;
  best_so_far_ant->tour = new int[problem_size+1];
  best_so_far_ant->visited = new bool[problem_size]; 
  prob_of_selection = new double[depth +1];
} 

double ** generate_2D_matrix_double(int n, int m){
  double **matrix;

  matrix = new double*[n];
  for ( int i = 0 ; i < n ; i++ ) {
    matrix[i] = new double[m];
  }
  //initialize the 2-d array
  for(int i = 0; i < n; i++){
    for(int j = 0; j < m; j++) {
      matrix[i][j] = 0.0;
    }
  }
  return matrix;
}

void allocate_structures(void){
  int i;

  pheromone = generate_2D_matrix_double(problem_size,problem_size);
  heuristic = generate_2D_matrix_double(problem_size,problem_size);
  total = generate_2D_matrix_double(problem_size,problem_size);
  nn_list = generate_2D_matrix_int(problem_size,depth);
}

void swap(int v[], int v2[],  int i, int j){
  int tmp;
  
  tmp = v[i];
  v[i] = v[j];
  v[j] = tmp;
  tmp = v2[i];
  v2[i] = v2[j];
  v2[j] = tmp;
}

void sort(int v[], int v2[], int left, int right){
  int k, last;

  if (left >= right) 
    return;
  swap(v, v2, left, (left + right)/2);
  last = left;
  for (k=left+1; k <= right; k++)
    if (v[k] < v[left])
      swap(v, v2, ++last, k);
  swap(v, v2, left, last);
  sort(v, v2, left, last);
  sort(v, v2, last+1, right);
}

void compute_nn_lists( void ){
  int i,j;
  int *distance_vector;
  int *help_vector;

  distance_vector = new int[problem_size];
  help_vector = new int[problem_size];
  //compute the nearest neigbhours of the objects
  for (j  = 0 ; j < problem_size; j++ ) { 
    for (i = 0 ; i < problem_size ; i++ ) { 
      distance_vector[i] = distances[j][i];
      help_vector[i] = i;
    }
    distance_vector[j] = INT_MAX;
    sort(distance_vector, help_vector, 0, problem_size-1);
    for (i = 0 ; i < depth ; i++ ) {
      nn_list[j][i] = help_vector[i];
    }
  }

  //free memory
  delete[] distance_vector;
  delete[] help_vector;
}

void init_pheromone_trails(double initial_trail){
  int i,j;
  
  for(i = 0; i < problem_size; i++){
    for(j = 0; j <=i; j++){
      pheromone[i][j] = initial_trail;
      pheromone[j][i] = initial_trail;
    }
  } 
}

void init_heuristic_info(void){
  int i,j;
  
  for(i = 0; i <problem_size; i++){
    for(j = 0; j <=i; j++){
      heuristic[i][j] = 1.0/(double)(distances[i][j] + EPSILON); //small value to avoid 1 div 0
      heuristic[j][i] = heuristic[i][j];
    }
  }
}

void compute_total_info(void){
  int i,j;
  
  for(i = 0; i < problem_size; i++){
    for(j = 0; j < i; j++){
      total[i][j] = pow(pheromone[i][j],alpha) * pow(heuristic[i][j],beta);
      total[j][i] = total[i][j];
    }
  }
}

/****************************************************************/
/*                    Construct Solutions                       */
/****************************************************************/
void ant_empty_memory(ant *a){
  int i;
  //clear previous ant solution
  for(i =0; i < problem_size; i++){
    a->visited[i] = false;
  }
}

double alg_random_number(int *idum){
  int k;
  double ans;
  //uniformly distributed random number [0,1]
  k =(*idum)/IQ;
  *idum = IA * (*idum - k * IQ) - IR * k;
  if (*idum < 0 ) *idum += IM;
  ans = AM * (*idum);
  return ans;
}

void place_ant(ant *a, int step){
  int rnd;
  //place ants to randomly selected cities
  rnd = (int)(alg_random_number(&seed) * (double)problem_size);
  a->tour[step] = rnd;
  a->visited[rnd] = true;
}

void choose_best_next(ant *a, int phase){
  int i,current, next;
  double value_best;

  next = problem_size;
  current = a->tour[phase-1]; //current object of ant
  value_best = -1.0;          //values in the list are always >=0.0
  //choose the next object with maximal (pheromone+heuristic) value 
  //among all objects of the problem 
  for(i = 0; i < problem_size; i++){
    if(a->visited[i] == false){
      //if object not visited
      if(total[current][i] > value_best){
	next = i;
	value_best = total[current][i];
      }
    }
  }
  a->tour[phase] = next;
  a->visited[next] = true;
}

void neighbour_choose_best_next(ant *a, int phase){
  int i,current,next,temp;
  double value_best, help;
  
  next = problem_size;
  current = a->tour[phase-1]; //current object of ant
  value_best = -1.0; //values in the list are always >=0.0
  //choose the next object with maximal (pheromone+heuristic) value 
  //among all the nearest neighbour objects
  for(i =0; i < depth; i++){
    temp = nn_list[current][i];
    if(a->visited[temp] == false){
      //if object not visited
      help = total[current][temp];
      if(help > value_best){
	value_best=help;
	next = temp;
      }
    }
  }
  if(next == problem_size){ 
    //if all nearest neighnour objects are already visited
    choose_best_next(a,phase);
  }else {
    a->tour[phase] = next;
    a->visited[next] = true;    
  }
}

void neighbour_choose_and_move_to_next(ant *a, int phase){
  int i,help, current, select;
  double rnd;
  double partial_sum = 0.0;
  double sum_prob = 0.0;
  double *prob_ptr;
  
  if((q_0 > 0.0) && (alg_random_number(&seed) < q_0)) {
    //with probability q_0 make the best possible choice
    neighbour_choose_best_next(a,phase);
    return;
  }
  
  prob_ptr = prob_of_selection; //selection probabilities of the nearest neigbhour objects
  current = a->tour[phase-1];   //current object
  //compute selection probabilities of nearest neigbhour objects
  for(i = 0; i < depth; i++){
    if(a->visited[nn_list[current][i]]){
      prob_ptr[i] = 0.0;
    }else{
      prob_ptr[i] = total[current][nn_list[current][i]];
      sum_prob +=prob_ptr[i];
    }
  }
  if(sum_prob <=0.0){
    //in case all neigbhbour objects are visited
    choose_best_next(a,phase);
  } else{
    //proabilistic selection (roullete wheel) 
    rnd = alg_random_number(&seed);
    rnd *= sum_prob;
    select = 0;
    partial_sum = prob_ptr[select];
    while(partial_sum<=rnd){
      select++;
      partial_sum+=prob_ptr[select];
    }
    //this may very rarely happen because of rounding if 
    //rnd is close to 1
    if(select==depth){
      neighbour_choose_best_next(a,phase);
      return;
    }
    help = nn_list[current][select];
    a->tour[phase] = help;
    a->visited[help] = true;
  }
}

void construct_solutions(void){
  int k,step;
  //clear memory of ants
  for(k =0; k < n_ants; k++){
    ant_empty_memory(&ant_population[k]);
  }
  step = 0; 
  //place ants on a random object
  for(k =0; k < n_ants; k++){
    place_ant(&ant_population[k],step);
  }
  //select object until all objects are visited
  while(step < problem_size-1){
    step++;
    for(k =0; k < n_ants; k++){
      neighbour_choose_and_move_to_next(&ant_population[k],step);
    }
  }
  step = problem_size;
  for(k =0; k < n_ants; k++){
    //close TSP tour, i.e., the first object needs to be identical with the last one.
    ant_population[k].tour[problem_size] = ant_population[k].tour[0];
    ant_population[k].tour_length = fitness_evaluation(ant_population[k].tour);//evalute 
  }
}

void choose_closest_next(ant *a, int phase){
  int i,current,next,min;  
  next = problem_size;
  current = a->tour[phase-1]; //current object of ant
  min = INFTY;
  //choose closest object used in the nn_tour()
  for(i = 0; i < problem_size; i++){
    if(a->visited[i] == false){
      //if object not visited
      if(distances[current][i] < min){
	next = i;
	min = distances[current][i];
      }
    } 
  }
  a->tour[phase] = next;
  a->visited[next] = true;
}

int nn_tour(void){
  int phase, help; 
  phase=help=0;  
  ant_empty_memory(&ant_population[0]);
  place_ant(&ant_population[0],phase);
  //compute the tour length of the nearest neigbour heuristic
  //used to initialize the pheromone trails
  while(phase < problem_size -1){
    phase++;
    choose_closest_next(&ant_population[0],phase);
  }
  phase = problem_size;
  ant_population[0].tour[problem_size] = ant_population[0].tour[0];
  ant_population[0].tour_length = fitness_evaluation(ant_population[0].tour);
  help = ant_population[0].tour_length;
  ant_empty_memory(&ant_population[0]);

  return help;
}

/****************************************************************/
/*                    Pheromone Update                          */
/****************************************************************/
void global_pheromone_deposit(ant *a){
  int i,j,h;
  double d_tau;
  d_tau = 1.0 / (double)a->tour_length;
  for(i = 0; i < problem_size; i++){
    j = a->tour[i];
    h = a->tour[i+1];
    pheromone[j][h]+= d_tau;
    pheromone[h][j] = pheromone[j][h];
  }
}

void evaporation(void){
 int i, j;

 for (i = 0 ; i < problem_size; i++) {
     for (j = 0 ; j <= i; j++) {
	pheromone[i][j] = (1 - rho) * pheromone[i][j];
	pheromone[j][i] = pheromone[i][j];
     }
 }
}

void as_pheromone_update(void){
  int k;

  evaporation();
  for(k = 0; k < n_ants; k++){
     global_pheromone_deposit(&ant_population[k]);
  }
}

void pheromone_update(){     
   as_pheromone_update(); 
   compute_total_info(); //heuristic info + pheromone trails
}

/****************************************************************/
/*                    Update Best Ants                          */
/****************************************************************/
int find_best(void){
  int k,min,k_min; 
  min = ant_population[0].tour_length;
  k_min = 0; 
  for(k = 1; k < n_ants; k++){
    if(ant_population[k].tour_length < min) {
      min=ant_population[k].tour_length;
      k_min = k;
    }
  }
  return k_min; //population best ant index
}

void copy_from_to(ant *a1, ant *a2){
  int i; 
  //ant2 is a copy of ant1
  a2->tour_length = a1->tour_length;
  for(i = 0; i < problem_size; i++){
    a2->tour[i]=a1->tour[i];
  }
  a2->tour[problem_size] = a2->tour[0];
}

void update_best(void){
  /*USE THIS METHOD TO RECORD THE BEST SO FAR SOLUTION AFTER A CHANGE FOR THE OFFLINE PERFORMANCE*/
  int iteration_best = find_best(); 
  if(ant_population[iteration_best].tour_length < best_so_far_ant->tour_length) {
    copy_from_to(&ant_population[iteration_best],best_so_far_ant);
    best_after_change = best_so_far_ant->tour_length; //*NOTE*: set best_after_change according to your algorithm implementation
  }
}

/****************************************************************/
/*                Update Statistics and Output                  */
/****************************************************************/
void open_stats(void){
  /*DO NOT CHANGE THIS METHOD*/
  perf_of_trials = new double[MAX_RUNS];
  //initialize and open output files
  perf_filename = new char[CHAR_LEN];
  sprintf(perf_filename, "Performance_D_%.2f_S_%d_%s.txt",
	 change_degree,change_speed,problem_instance);
  //for performance
  if ((log_performance = fopen(perf_filename,"a")) == NULL) { exit(2); }
}

double mean(double* values, int size){  
  /*DO NOT CHANGE THIS METHOD*/
  int i;
  double m = 0.0;  
  for (i = 0; i < size; i++){
      m += values[i];
  }
  m = m / (double)size;
  return m; //mean 
}

double stdev(double* values, int size, double average){
  /*DO NOT CHANGE THE FOLLOWING LINES*/
  int i;
  double dev = 0.0;
  
  if (size <= 1)
    return 0.0;
  for (i = 0; i < size; i++){
    dev += ((double)values[i] - average) * ((double)values[i] - average);
  }
  return sqrt(dev / (double)(size - 1)); //standard deviation
}

void close_stats(void){
  /*DO NOT CHANGE THIS METHOD*/
  int i,j;
  double perf_mean_value, perf_stdev_value;

  fprintf(log_performance,"Statistical results\n");
  //For statistics
  for(i = 0; i < MAX_RUNS; i++){     
    fprintf(log_performance, "Run: %d  %.2f", i, perf_of_trials[i]);
    fprintf(log_performance,"\n");   
  }  
  perf_mean_value = mean(perf_of_trials,MAX_RUNS);
  perf_stdev_value = stdev(perf_of_trials,MAX_RUNS,perf_mean_value);  
  fprintf(log_performance,"Mean %f\t ",perf_mean_value);
  fprintf(log_performance,"\tStd Dev %f\t ",perf_stdev_value);
  cout << "Mean " << perf_mean_value << " Std " << perf_stdev_value << endl;   
  fclose(log_performance);
  //free memory
  delete[] perf_of_trials;
}

void init_try(){  
  /*NOTE* MODIFY ACCORDING TO YOUR IMPLEMENTATION 
  change the best_so_far_ant according to your algorithm implementation*/
  best_so_far_ant->tour_length = INFTY; //reset best solution found

  current_iteration=1;                  //set iteration for a new Run
  evaluations = 0;                      //reset termination condition
  perf = 0.0;                           //for offline performance
}

void exit_try(int t){ 
 /*DO NOT CHANGE THIS METHOD*/
 perf_of_trials[t-1] = perf / (MAX_EVALUATIONS/SAMPLING);
 cout << perf_of_trials[t-1] << endl;
}

void notify_algorithm(){
  //*NOTE*: These actions stand only for ACO 
  //algorithms to notify the algorithm about the dynamic 
  //change. In case an EA is used, simply
  //re-evaluate the individuals in the population 
  //using fitness_evaluation()
  compute_nn_lists();
  init_heuristic_info();
  compute_total_info();  
  //*NOTE*: change the best_so_far_ant according to your algorithm implementation
  //Reset best solution after a change to
  //calculate the modified offline performance
  best_so_far_ant->tour_length = INFTY;
}

void initialize_algorithm(){
  //initialize only the algorithmic structures 
  //since the initial objects are added
  //at the beggining of each Run and the 
  //dynamic environments are re-initialized
  //using initialize_environment()
  compute_nn_lists();             //reset nearest neighbour objects
  init_heuristic_info();          //initialize heuristic info
  trail0 = 1.0 / (rho * nn_tour()); 
  init_pheromone_trails(trail0);  //initialize pheromone trails
  compute_total_info();           //combine heuristic+pheromone
}

//end ACO

/****************************************************************/
/*                Main Function (DBGP+ACO)                      */
/****************************************************************/
int main(int argc, char *argv[]) {
  // read in parameters
  problem_instance = argv[1];
  change_degree = atof(argv[2]);
  change_speed = atoi(argv[3]); 

  read_problem(problem_instance);   //Read TSP from file
  check_input_parameters();         //validate the parameters  

  open_stats();
  
  //ANT SYSTEM initialization
  set_algorithm_parameters();
  allocate_ants();
  allocate_structures();
  
  for(int run = 1; run <= MAX_RUNS; run++){
    /*DO NOT CHANGE THE FOLLOWING LINES*/
    cout<< "-------------Run: " << run << "------------------" << endl; 

    srand(1);                       //static seed reset for the changes
    seed =  run;                    //changing seed for the algorithms  

    initialize_environment();       //set DBGP for a new Run     
    init_try();                     //re-initialize algorithmic structures for a new run   
    initialize_algorithm();
    while(evaluations <= MAX_EVALUATIONS){//termination not met
      /*ALGORITHM HERE*/
      //Ant System Algorithm
      construct_solutions();          
      update_best();   
      pheromone_update();
       
      /*DO NOT CHANGE THE FOLLOWING LINES*/    
      //environmental changes (integration of ACO with DBGP) 
      if(evaluations%change_speed <= 10){ //period of change    
        change_environment();//change the encoding of the problem instance	
        notify_algorithm();  //move population to a different fitness landscape location
      }
      current_iteration++;
    } 
    exit_try(run);  
  }  
  close_stats();
 
  



  //free memory from the DBGP impemenation
  delete[] masked_objects;
  delete[] init_objects;
  for(int i = 0; i < problem_size; i++) {
    delete[] distances[i];
  }
  delete[] distances;
  //free memory from the ACO implementation
  delete[] best_so_far_ant->tour;
  for(int i = 0; i < n_ants; i++){
    delete[] ant_population[i].tour;
    delete[] ant_population[i].visited;
  }
  delete[] ant_population; 
 
  for(int i = 0; i < problem_size; i++){
    delete[] pheromone[i];
    delete[] heuristic[i];
    delete[] total[i];
    delete[] nn_list[i];
  }
  delete[] pheromone;
  delete[] heuristic; 
  delete[] total;
  delete[] nn_list;
  delete[] prob_of_selection;   
  delete[] perf_filename; 
  return 0;
}
