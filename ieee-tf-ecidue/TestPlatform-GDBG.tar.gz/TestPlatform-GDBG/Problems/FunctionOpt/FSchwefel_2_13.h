#ifndef FSCHWEFEL_2_13_H
#define FSCHWEFEL_2_13_H

#include "BenchmarkFunction.h"

class FSchwefel_2_13 : public BenchmarkFunction
{
    public:

        FSchwefel_2_13();
        FSchwefel_2_13(const int rId, const int rDimNumber, char *rName);
        FSchwefel_2_13(const int rId, const int rDimNumber, char *rName, double rL,double rU);
        FSchwefel_2_13(const int rId, const int rDimNumber, char *rName, double *rL, double *rU);
        virtual ~FSchwefel_2_13();
    protected:
        void initialize();
        void setGlobalOpt();
        void loadData();
        virtual double evaluate_(double const *x);
    private:

    public:
          int ** a;
          int ** b;
          double * alpha;
};

#endif // FSCHWEFEL_2_13_H
