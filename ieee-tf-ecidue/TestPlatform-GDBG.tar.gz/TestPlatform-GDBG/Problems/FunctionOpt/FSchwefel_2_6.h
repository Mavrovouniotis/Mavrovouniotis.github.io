#ifndef FSCHWEFEL_2_6_H
#define FSCHWEFEL_2_6_H

#include "BenchmarkFunction.h"
class FSchwefel_2_6 : public BenchmarkFunction
{
    public:

        FSchwefel_2_6();
        FSchwefel_2_6(const int rId, const int rDim, char *rName);
        FSchwefel_2_6(const int rId, const int rDim,  char *rName, double rL,double rU);
        FSchwefel_2_6(const int rId,  const int rDim, char *rName, double *rL, double *rU);
        virtual ~FSchwefel_2_6();
    protected:
        void initialize();
        void setGlobalOpt();
        void loadData();
        virtual double evaluate_(double const *x);
    private:
          int ** a;
          double * b;

};

#endif // FSCHWEFEL_2_6_H
