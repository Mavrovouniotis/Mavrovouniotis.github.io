
#include "StringMatching.h"

StringMatching::~StringMatching(){

	if(m_string.size()>0) m_string.clear();
	for(int i=0;i<m_dimNumber;i++)  {delete (Boundary<char>*) m_searchRange[i]; }

}

StringMatching::StringMatching():Problem(){}

StringMatching::StringMatching(char *file):Problem(StringMatchingPro,0,C_STRING,CAT_STATIC){

	string s;
	if(file==0){
		Throw(Invalid_argument("the file name cannot be empty!"));
		return ;
	}

	s="Problems/Combination/StringMatching/Data/";
	s.insert(0,Global::g_workdir );//probDataPath
	s+=file;
	s+=".txt";

	ifstream in(s.c_str());
	if(in.fail()){
		Throw(Invalid_argument("the file doesnot exist!"));
		return ;
	}
	strcpy(this->ma_name,"String Matching Problem");

	setProblemType(MAX_OPT);
	in>>this->m_dimNumber;  //read the string length
	this->allocateMemory(this->m_dimNumber);
	Global::g_dimNumber=this->m_dimNumber;
	for(int i=0;i<m_dimNumber;i++)  {m_searchRange[i]=new Boundary<char>(); }
	char l,u;
	in>>l>>u;				// read the string range
	this->setSearchRange<char>(l,u);
	m_string.resize(m_dimNumber);
	for(int i=0;i<this->m_dimNumber;i++){
		//in>>c;
		in>>m_string[i];
	};
	in.close();
}

double StringMatching::evaluate(const char *s, bool rFlag){
	int count=0;
	for(int i=0;i<m_dimNumber;i++){
		if(s[i]==m_string[i]) count++;
	}
	if(rFlag) this->m_evals++;
	return count*1./m_dimNumber;
}
