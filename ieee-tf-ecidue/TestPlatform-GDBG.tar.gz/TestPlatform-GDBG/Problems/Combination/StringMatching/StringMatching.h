#ifndef STRING_MATCHING
#define STRING_MATCHING

#include "../../Problem.h"

class StringMatching: public Problem
{
private:
	vector<char> m_string; 
public:
	~StringMatching();
	StringMatching();
	StringMatching(char *file);
	//double evaluate(char *s,int idxLow, int idxHigh, bool rFlag=true);		//max value 1.0, minimum value 0
	double evaluate(const char *s, bool rFlag=true);
	bool getKnownFlagGOpt(){ return true;}
	float getObjGlobalOpt(){return 1.0;}
};

#endif