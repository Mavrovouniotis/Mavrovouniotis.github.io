LIBRARY OF EVOLUTIONARY ALGORITHMS 

This is a part of an open project with the aim of providing state-of-the-art algorithms, problems, 
and algorithms' performance metrics for researchers in the area of evolutionary computation. Based on
this framework, you can easily implement your ideas and add the codes into this library. More important, 
you will be also able to compare with other state-of-the-art algorithms without implementing them under a 
fair environment. In addition, this lib will grow and be updated by new algorithms and problems as time 
goes on. If you want to contribute to this project, please contact Dr. Changhe Li with the email address:
 changhe.lw@gmail.com. 

   

This library has three components: algorithms, problems, and algorithms' performance evaluation. Class structure
logic is as follows:

//*************************************************************************************//
Class structure
//*************************************************************************************//

Algorithms: the followings are the basic logic of the algorithm design 

Chromosome................................................ the most fundamental class, which can take composite encoding scheme,e.g., A b 1.23 ! & true 59 ....
Individual................................................ the simple individual class 
Algorithm................................................. the base class for any algorithms
	|
	+Population............................................. the template population class


To add a new specific algorithm, what you need to do is as follows (take a simple PSO algorithm as an example):

PSOIndividual: public Individual
PSOPopulation: public Population<PSOIndividual>

//**************************************************************************************************//
Problems: the followings are some problem examples
//**************************************************************************************************//

Problem.................................................... the base class for all problems
	|
	+BenchmarkFunction........................................ the base class for all function optimization problems
	|	|
	|	+FSphere................................................ the Sphere function f(x)=x*x
	+DynamicProblem........................................... the base class for dynamic optimization problems(DOPs)
		|
		+DynamicContinuous......................................  the base class for DOPs in continuous space
			|
			+RealDBG.............................................. the base class for GDBG benchmark
			|	|
			|	+CompositionDBG..................................... the Composition problems in GDBG 
			|	|
			|	+RotationDBG......................................... the Rotation problems in GDBG
			|
			+MovingPeak............................................ the Moving Peaks problem
			|
			+DF1................................................... the DF1 problem


//***************************************************************************************************//
Performance metrics:
//**************************************************************************************************//

PerformSingleObj...............................................the performance measurement for single objective optimization problem


Other major files:

Global.h........................................................class for global variables  
StructDec.h.....................................................struct declaration file
newran.h........................................................ random number generator: From library http://www.robertnz.net/nr02doc.htm


Currently, this lib has included two simple PSO algorithms, a simple DE algorithm, and the CPSO, CPSOR algorithms from the following two papers

1. CPSO: S. Yang and C. Li, “A clustering particle swarm optimizer for locating and tracking multiple optima in dynamic environments,�?IEEE Trans.
Evol. Comput., vol. 14, no. 6, pp. 959�?74, 2010.
2. CPSOR:  C.Li and S.Yang A General Framework of Multi-Population Methods with Clustering in Undetectable Dynamic Environments , accepted by IEEE TEC


Howow to run the program with each particular algorithm, please find the corresponding instruction in the beginning of the main() function and parameter.h file

You can develop your codes in both Visual studio 2012 in Windows and CODE::BLOCK in Ubuntu, corresponding project files are EAlib.sln and EAlib.cbp, respectively. A makefile is also available to compile the program.  If you have any question about this lib, please contact Changhe Li with changhe.lw@gmail.com. 
