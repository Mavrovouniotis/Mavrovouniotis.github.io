/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 15 Nov 2011
// Last modified:

#ifndef SIMPLEMULTIDE_H
#define SIMPLEMULTIDE_H

#include "../DEPopulation.h"
#include "../DEIndividual.h"
extern bool g_moment2IncreaseDiv;

class SimpleMultiDE : public DEPopulation<DEIndividual>
{
    public:
     static int ms_numPop;

        SimpleMultiDE() {
             strcpy(this->ma_name,"mDE");
            for(int i=0;i<ms_numPop;i++){
                msp_subPop.push_back(new SimpleMultiDE(10));
            }
        }
        SimpleMultiDE(const int rSize,bool mode=true):DEPopulation<DEIndividual>(rSize,mode){
            setMutationStrategy(DE_best_2);
        }
        virtual ~SimpleMultiDE() {}
        int run(){

			#ifdef PRINT_POPULATION
			ostringstream oss;
			oss<<"Result//"<<this->ma_name<<"avgRadius"<<Global::g_runIdx<<".txt";
			ofstream out(oss.str().c_str());
			#endif
			#ifdef PRINT_POPULATION
			//print populations after a change
			printPops();
			#endif
           while(!gIsTerminate()){
				//cout<<Global::g_runIdx+1<<" "<<Global::gp_problem->getEvaluations()<<" "<<getAvgCurRadius()<<" "<<getAvgDistanceBetwPop()<<endl;
			
				#ifdef EALIB
				if(gIsDynamicAlg()){
					float peaksf=computePeaksFound();
					PopulationInforDOP::getPopInfor()->input(Global::gp_problem->getEvaluations(),ms_gNumIndis,msp_subPop.size(),peaksf, 
					dynamic_cast<DynamicContinuous*>(Global::gp_problem)->getNumofVisablePeaks(),0,
					0,0,0,dynamic_cast<DynamicContinuous*>(Global::gp_problem)->getPeaksTracedQaulity(),getAvgRadiusQaulity(),
					dynamic_cast<DynamicContinuous*>(Global::gp_problem)->isGOptTracked());
				}
				#endif

				#ifdef PRINT_POPULATION
				   out<<Global::gp_problem->getEvaluations()<<" "<<getAvgCurRadius()<<" "<<getAvgDistanceBetwPop()<<endl;
				#endif
				for(unsigned int i=0;i<ms_numPop;i++){
					 msp_subPop[i]->evolve();
					 if(g_moment2IncreaseDiv) break;
				}
				if(gIsTerminate()) break;
				if(g_moment2IncreaseDiv){
					for(unsigned int i=0;i<ms_numPop;i++){
						 dynamic_cast<SimpleMultiDE*>(msp_subPop[i])->reInitialize(); 
						 if(gIsTerminate()) break;
					}
					g_moment2IncreaseDiv=false;
				}
	
            }

            for(unsigned int i=0;i<ms_numPop;i++)   delete  msp_subPop[i];
            msp_subPop.clear();

			#ifdef PRINT_POPULATION
			out.close();
			#endif

            return 0;

        }
    protected:
    private:
};
int SimpleMultiDE::ms_numPop=10;
#endif // SIMPLEMULTIDE_H
