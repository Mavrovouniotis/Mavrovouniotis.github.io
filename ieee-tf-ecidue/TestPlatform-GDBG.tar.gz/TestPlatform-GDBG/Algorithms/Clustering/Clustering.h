/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 21 September 2011
// Last modified:
#ifndef CLUSTERING_H
#define CLUSTERING_H

#include "Group.h"

#ifdef DEMON_EALIB
#include "../../buffer/buffer.h"
#endif

template<class T>
class Cluster{
public:
	Group<T> *mp_group;
	int m_number;
	int m_initialNumber;
	/*distance between all objects*/
	double **mpp_dis;
	//20/05/2013
	double m_interDiversity,m_intraDiversity;
	/*distance between groups*/
	double **mpp_groupDis;

public:
	Cluster();
	Cluster( T *p,const int num);
	void initialize(const Cluster &clst);
	void initialize( T *p,const int num);
	~Cluster();
	virtual void allocateMemory(const int rNum, const int rInitialNum);
	virtual void freeMemory();

	Cluster &operator =(const Cluster &clst);
	void computeDistMatrix();
	void roughClustering();
	double computerGroupDist(const int from,const int to);
	bool isNearestGroup(int & g1, int & g2, bool constrain=true);
	void deleteGroup(const int index, const int id=-1);
	void addGroup(Group<T> &g);

	//17/05/2013
	void adaptiveClustering();
	void updateDiversity();
	void updateGroupDistance(int id);
	double getGroupDistance(int i, int j);

	bool isNearestGroup2(int & g1, int & g2, bool constrain);
};

// implementation of Clustering class
template<class T>
Cluster<T>::Cluster():m_initialNumber(0){
	m_number=0;
	mp_group=0;
	mpp_dis=0;
	mpp_groupDis=0;
}

template<class T>
void Cluster<T>::allocateMemory(const int rNum, const int rInitialNum){
    mp_group=new Group<T>[rNum];
    mpp_dis=new double*[rInitialNum];
	for(int i=0;i<rInitialNum;i++)
		mpp_dis[i]=new double[rInitialNum];
	mpp_groupDis=new double*[rInitialNum];
	for(int i=0;i<rInitialNum;i++)
		mpp_groupDis[i]=new double[rInitialNum];
}

template<class T>
Cluster<T>::Cluster(T *p, const int num):m_number(num),m_initialNumber(num){
	m_number=num;
	allocateMemory(m_number,m_initialNumber);

	for(int i=0;i<m_number;i++)
		mp_group[i].initialize(p[i],i);

	computeDistMatrix();
}
template<class T>
void Cluster<T>::initialize( T *p,const int num){
	freeMemory();

	m_initialNumber=num;
	m_number=num;

	allocateMemory(m_number,m_initialNumber);

	for(int i=0;i<m_number;i++)
		mp_group[i].initialize(p[i],i);
	computeDistMatrix();
}
template<class T>
void Cluster<T>::initialize(const Cluster &clst){
	if(clst.m_initialNumber==0) return;

	m_initialNumber=clst.m_initialNumber;
	m_number=clst.m_number;

	allocateMemory(m_number,m_initialNumber);

	for(int i=0;i<m_number;i++)
		mp_group[i].initialize(clst.mp_group[i]);

	for(int i=0;i<m_initialNumber;i++)
		for(int j=0;j<m_initialNumber;j++)
			mpp_dis[i][j]=clst.mpp_dis[i][j];

	for(int i=0;i<m_initialNumber;i++)
		for(int j=0;j<m_initialNumber;j++)
			mpp_groupDis[i][j]=clst.mpp_groupDis[i][j];

}
template<class T>
Cluster<T>::~Cluster(){
	freeMemory();
}
template<class T>
void Cluster<T>::computeDistMatrix(){
	// only called by constructor
	for(int i=0;i<m_initialNumber;i++){
		mpp_dis[i][i]=-1; //infinite large
		for(int j=0;j<i;j++){
			mpp_dis[i][j]=mpp_dis[j][i]=mp_group[i].m_center.getDistance(mp_group[j].m_center);
			mpp_groupDis[i][j]=mpp_groupDis[j][i]=mpp_dis[i][j];
		}
	}

}
template<class T>
void Cluster<T>::roughClustering(){
	while(1){
		int i=0;
		while(i<m_number&&mp_group[i].m_number>1) i++;
		if(i==m_number) break;
		int g1,g2;
		if(!isNearestGroup(g1,g2)) break;
		mp_group[g2].merge(mp_group[g1]);
		updateGroupDistance(g2);
		deleteGroup(g1);
	}
	for(int i=0;i<m_number;i++) mp_group[i].calculateRadius();
}
template<class T>
void Cluster<T>::deleteGroup(const int index, const int ID){
	//delete either by index or ID
	int num=m_number-1;
	if(num<1){
		freeMemory();
		return;
	}
	//20/05/2013
	int id;
	if(-1==ID) id=mp_group[index].m_ID;
	else id=ID;

	Group<T> *g=new Group<T>[num];
	for(int i=0,j=0;i<num;i++,j++){
		if(mp_group[j].m_ID!=id){
			g[i].initialize(mp_group[j].m_number,mp_group[j].m_ID);
			g[i]=mp_group[j];
		}else
			i--;
	}
	delete [] mp_group;
	mp_group=g;
	m_number--;
}
template<class T>
double Cluster<T>::computerGroupDist(const int from,const int to){
	return mp_group[from].m_center.getDistance(mp_group[to].m_center);
}
template<class T>
bool Cluster<T>::isNearestGroup(int & g1, int & g2, bool constrain){

	if(m_number<=1) {
	 g1=0;
	 g2=0;
	 return false;
	}
	bool flag_fail=true;
	double l,u,Min_dis=0,dist;
	for(int i=0;i<Global::g_dimNumber;i++){
        Global::gp_problem->getSearchRange<double>(l,u,i);
        Min_dis+=(u-l)*(u-l);
    }
    Min_dis=sqrt(Min_dis);

	for(int i=0;i<m_number;i++){
		// can't merge two mp_groups whose m_number are both greater than 1
		for(int j=0;j<m_number;j++){
				if(j==i) continue;
				if(constrain&&mp_group[i].m_number+mp_group[j].m_number>Global::g_subSize) continue;
				//dist=computerGroupDist(i,j);
				dist=getGroupDistance(i,j);
				if(Min_dis>dist){
					Min_dis=dist;
					g1=i;
					g2=j;
					flag_fail=false;
				}
		}
	}

	return !flag_fail;

}


template<class T>
void Cluster<T>::freeMemory(){
	if(m_number>0){
		delete [] mp_group;
		mp_group=0;
		for(int i=0;i<m_initialNumber;i++){
			delete [] mpp_dis[i];
			mpp_dis[i]=0;
			delete [] mpp_groupDis[i];
			mpp_groupDis[i]=0;
		}
		delete[] mpp_dis;
		delete [] mpp_groupDis;
		mpp_dis=0;
		m_number=0;
		m_initialNumber=0;
		mpp_groupDis=0;
	}
}
template<class T>
Cluster<T> &Cluster<T>::operator =(const Cluster<T> &clst){
	if(clst.m_initialNumber==0) return *this;
	freeMemory();
	initialize(clst);
	return *this;
}

template<class T>
void Cluster<T>::adaptiveClustering(){
	//stringstream s;
	//s<<dynamic_cast<DynamicContinuous*>(Global::gp_problem)->getNumberofPeak();
	//s<<"best.txt";
	//ofstream out(s.str().c_str());
	while(1){
		int g1,g2;
		int num=0;
		for(int i=0;i<m_number;i++) if(mp_group[i].m_number>1) num++;
		if(num>=m_number*0.8) break;
		if(!isNearestGroup(g1,g2,false)) break;
		double r1,r2;
		r1=mp_group[g1].m_radius;
		r2=mp_group[g2].m_radius;
		Group<T> t_g1(mp_group[g1]),t_g2(mp_group[g2]);


		//out<<'\t'<<m_number<<" "<<'\t'<<r1<<"("<<mp_group[g1].m_number<<") "<<'\t'<<r2<<"("<<mp_group[g2].m_number<<") ";
		//out<<'\t'<<m_number<<" "<<'\t'<<mp_group[g1].m_number<<" "<<'\t'<<mp_group[g2].m_number<<" ";

		mp_group[g2].merge(mp_group[g1]);
		//out<<" "<<'\t'<<mp_group[g2].m_radius<<" "<<'\t'<<mp_group[g2].m_radius/(r1+r2)<<" ";

		updateGroupDistance(g2);
		deleteGroup(g1);
		double intraDiv=m_intraDiversity;
		updateDiversity();

		//out<<" "<<'\t'<<(m_intraDiversity-intraDiv)/intraDiv<<endl;

		if(m_interDiversity<=m_intraDiversity){
			deleteGroup(-1,t_g2.m_ID);
			addGroup(t_g1);
			addGroup(t_g2);
			break;
		}

	}
	/*out<<endl;
	double avgr=0;
	for(int i=0;i<m_number;i++)  {out<<i+1<<" "<<mp_group[i].m_number<<" "<<mp_group[i].m_radius<<endl;
	avgr+= mp_group[i].m_radius;
	}
	out<<"average radius"<<avgr/m_number;
	out.close();*/
}

template<class T>
void Cluster<T>::updateDiversity(){
	m_interDiversity=m_intraDiversity=0;
	//calculate inter-diversity
	for(int i=0;i<m_number;i++){
		for(int j=0;j<i;j++){
			m_interDiversity+=mpp_groupDis[mp_group[i].m_ID][mp_group[j].m_ID];
		}
	}
	// calulate intra-diversity
	for(int i=0;i<m_number;i++){
		double div=0;
		for(int j=0;j<mp_group[i].m_number;j++){

			for(int k=0;k<j;k++){
				div+=mpp_dis[mp_group[i].mp_member[j].m_id-1][mp_group[i].mp_member[k].m_id-1];
			}

		}
		m_intraDiversity+=div;///(mp_group[i].m_number*(mp_group[i].m_number+1.)/2.);
	}
	//m_interDiversity/=(m_number*(m_number+1.)/2);
	//m_intraDiversity/=m_number;

	Global::g_interDiversity=m_interDiversity;
	Global::g_intraDiversity=m_intraDiversity;
}

template<class T>
void Cluster<T>::updateGroupDistance(int id){
	int groID, objID;
	groID=mp_group[id].m_ID;
	for(int i=0;i<m_number;i++) {
		objID=mp_group[i].m_ID;
		if(i!=id) mpp_groupDis[objID][groID]=mpp_groupDis[groID][objID]=computerGroupDist(i,id);
	}
}

template<class T>
double Cluster<T>::getGroupDistance(int i, int j){
	return mpp_groupDis[mp_group[i].m_ID][mp_group[j].m_ID];
}

template<class T>
bool Cluster<T>::isNearestGroup2(int & g1, int & g2, bool constrain){

	if(m_number<=1) {
	 g1=0;
	 g2=0;
	 return false;
	}
	bool flag_fail=true;
	double l,u,Min_dis=0,dist;
	for(int i=0;i<Global::g_dimNumber;i++){
        Global::gp_problem->getSearchRange<double>(l,u,i);
        Min_dis+=(u-l)*(u-l);
    }
    Min_dis=sqrt(Min_dis);
	for(int i=0;i<m_number;i++) mp_group[i].m_flag=true;

	for(int i=0;i<m_number;i++){
		for(int j=0;j<m_number;j++){
				if(j==i) continue;
				if(constrain&&((mp_group[i].m_flag&&mp_group[j].m_flag)||mp_group[i].m_number+mp_group[j].m_number>Global::g_subSize)){
					mp_group[i].m_flag=false;
					mp_group[j].m_flag=false;
					continue;
				}
				dist=getGroupDistance(i,j);
				if(Min_dis>dist){
					Min_dis=dist;
					g1=i;
					g2=j;
					flag_fail=false;
				}
		}
	}

	return !flag_fail;

}

template<class T>
void Cluster<T>::addGroup(Group<T> &gr){

	Group<T> *g=new Group<T>[m_number+1];
	for(int i=0;i<m_number;i++){
		g[i].initialize(mp_group[i].m_number,mp_group[i].m_ID);
		g[i]=mp_group[i];

	}

	g[m_number].initialize(gr.m_number,gr.m_ID);
	g[m_number]=gr;

	delete [] mp_group;
	mp_group=g;
	m_number++;
}

#endif // CLUSTERING_H
