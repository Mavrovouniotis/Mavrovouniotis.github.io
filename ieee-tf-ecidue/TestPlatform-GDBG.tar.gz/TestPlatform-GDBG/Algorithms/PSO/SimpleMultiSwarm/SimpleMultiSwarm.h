/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 15 Nov 2011
// Last modified:

#ifndef SIMPLEMULTISWARM_H
#define SIMPLEMULTISWARM_H
#include "../Particle.h"
#include "../Swarm.h"

extern bool g_moment2IncreaseDiv;

class SimpleMultiSwarm : public Swarm<Particle>
{
    public:
        SimpleMultiSwarm() {
            strcpy(this->ma_name,"mPSO");
            for(int i=0;i<ms_numPop;i++){
                msp_subPop.push_back(new SimpleMultiSwarm(10));
            }
        }
        SimpleMultiSwarm(const int rSize,bool mode=true):Swarm<Particle>(rSize,mode){

        }
        virtual ~SimpleMultiSwarm() {}
		double getAvgVelocityPops(){
			
			double v=0;
			for(int i=0;i<ms_numPop;i++) v+=dynamic_cast <Swarm<Particle> *>(msp_subPop[i])->getAvgVelocity();
			return v/ms_numPop;

		}
        int evolve(){
            if(this->m_popsize<1) return 0;

        for(int i=0;i<this->m_popsize;i++){
		    // using gbest mode
        this->mp_pop[i].moveBound(this->mp_pop[i].m_pbest,this->m_best,m_W,m_C1,m_C2);
		if(gIsDynamicAlg()){
			int time=Global::g_changeFre*Global::g_diversityDegree;
			if(Global::g_diversityDegree==0) g_moment2IncreaseDiv=false;
			else if (Global::gp_problem->getEvaluations()%time==0)
				g_moment2IncreaseDiv=true;
		}

		#ifdef PRINT_POPULATION
		//print populations just before a change occurs
		if(gIsDynamicAlg()&&dynamic_cast<DynamicProblem*>(Global::gp_problem)->predictChange(1)){
			printPops();
		}
		#endif
		
		if(gIsDynamicAlg()&&dynamic_cast<DynamicProblem*>(Global::gp_problem)->getFlagTimeLinkage()&&Global::g_flagTimeLinkage){
			this->updateMemoryAll();
			Global::g_flagTimeLinkage=false;
		}

		if(gIsTerminate())
			return 0;

		if(this->mp_pop[i].m_pself>this->mp_pop[i].m_pbest){
			this->mp_pop[i].m_pbest=this->mp_pop[i].m_pself;
			if(this->mp_pop[i].m_pself>this->m_best){
				this->m_best=this->mp_pop[i].m_pself;
				this->m_center=this->m_best;
			}
		}

		if(gIsDynamicAlg()&&Global::gp_problem->getEvaluations()%(dynamic_cast<DynamicProblem*>(Global::gp_problem)->getChangeFre())==0){
			if(dynamic_cast<DynamicProblem*> (Global::gp_problem)->getFlagDimensionChange()) {

                if(dynamic_cast<DynamicProblem*> (Global::gp_problem)->getDirDimensionChange()==true)  increaseDimensionAll();
                else decreaseDimensionAll();
                return 2;
                }

			this->updateMemoryAll();
			#ifdef PRINT_POPULATION
			//print populations after a change
			printPops();
			#endif
			return 1;
		}

	}

		updateCurRadius();
		this->m_evoNum++;

	   return 0;
        }
        int run(){
	

			#ifdef PRINT_POPULATION
			ostringstream oss;
			oss<<"Result//"<<this->ma_name<<"avgRadius"<<Global::g_runIdx<<".txt";
			ofstream out(oss.str().c_str());
			#endif
			#ifdef PRINT_POPULATION
			//print populations after a change
			printPops();
			#endif
           while(!gIsTerminate()){
            //cout<<Global::g_runIdx+1<<" "<<Global::gp_problem->getEvaluations()<<" "<<getAvgCurRadius()<<" "<<getAvgDistanceBetwPop()<<endl;
			
			#ifdef EALIB
			if(gIsDynamicAlg()){
			float peaksf=computePeaksFound();
			PopulationInforDOP::getPopInfor()->input(Global::gp_problem->getEvaluations(),ms_gNumIndis,msp_subPop.size(),peaksf, 
			dynamic_cast<DynamicContinuous*>(Global::gp_problem)->getNumofVisablePeaks(),0,
			0,0,0,dynamic_cast<DynamicContinuous*>(Global::gp_problem)->getPeaksTracedQaulity(),getAvgRadiusQaulity(),
			dynamic_cast<DynamicContinuous*>(Global::gp_problem)->isGOptTracked());
			}
			#endif
			#ifdef PRINT_POPULATION
			   out<<Global::gp_problem->getEvaluations()<<" "<<getAvgCurRadius()<<" "<<getAvgDistanceBetwPop()<<" "<<getAvgVelocityPops()<<endl;
			#endif
            for(unsigned int i=0;i<ms_numPop;i++){
                 msp_subPop[i]->evolve(); 
				 if(g_moment2IncreaseDiv) break;
            }

			if(gIsTerminate()) break;

			if(g_moment2IncreaseDiv){

				for(unsigned int i=0;i<ms_numPop;i++){
					 dynamic_cast <SimpleMultiSwarm*>(msp_subPop[i])->reInitialize(); 
					 if(gIsTerminate()) break;
				}
				
				g_moment2IncreaseDiv=false;
			}
	
            }

            for(unsigned int i=0;i<ms_numPop;i++)   delete  msp_subPop[i];
            msp_subPop.clear();
			#ifdef PRINT_POPULATION
			out.close();
			#endif
            return 0;

        }
    public:
    static int ms_numPop;
    protected:
    private:
};
int SimpleMultiSwarm::ms_numPop=10;
#endif // SIMPLEMULTISWARM_H
