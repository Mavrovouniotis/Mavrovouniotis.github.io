/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 15 Nov 2011
// Last modified:

#ifndef ISLAND_H
#define ISLAND_H
#include "../Population.h"

template <typename T>
class Island: public Population<T>
{
    public:
        Island():Population<T>(){}
        virtual ~Island() {}
    public:
        static int ms_mgrFre;        // communication frequency
        static float ms_magnitude;      // the number of individuals transferred to neighbor populations
        static bool ms_isSynchronous;	// two ways of migration, synchronous and asynchronous
        static MigrationMode ms_mgrMode;
        static bool ms_mgrReplCondi;
        static MigrationTopology ms_mgrTopo;
        static void migrate(){
            if(ms_isSynchronous){
                switch(ms_mgrTopo){
                    case Migration_Ring:
                    switch(ms_mgrMode){
                        case Migration_Best:
                            if(ms_mgrReplCondi){
                                for(unsigned int i=0;i<Population<T>::msp_subPop.size();i++){

                                }
                            }else {

                            }
                        break;
                        case Migration_Worst:
                            if(ms_mgrReplCondi){

                            }else{

                            }
                        break;
                        case Migration_Random:
                            if(ms_mgrReplCondi){

                            }else{

                            }
                        break;
                    }

                    break;
                    case Migration_Broadcast:
                    break;
                }
            }else{
                switch(ms_mgrTopo){
                    case Migration_Ring:
                    switch(ms_mgrMode){
                        case Migration_Best:
                            if(ms_mgrReplCondi){
                                for(unsigned int k=0;k<Population<T>::msp_subPop.size();k++){
                                    if(Population<T>::msp_subPop[k]->m_evoNum%ms_mgrFre==0){
                                        int idxw=Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->findWorst();
                                        int idxb=Population<T>::msp_subPop[k]->findBest();
                                        if(idxw!=-1&&idxb!=-1&&Population<T>::msp_subPop[k]->mp_pop[idxb]>Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->mp_pop[idxw]){
                                            Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->mp_pop[idxw]=Population<T>::msp_subPop[k]->mp_pop[idxb];
                                        }
                                    }

                                }
                            }else {
                                for(unsigned int k=0;k<Population<T>::msp_subPop.size();k++){
                                    if(Population<T>::msp_subPop[k]->m_evoNum%ms_mgrFre==0){
                                        int idxw=Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->findWorst();
                                        int idxb=Population<T>::msp_subPop[k]->findBest();
                                        if(idxw!=-1&&idxb!=-1){
                                            Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->mp_pop[idxw]=Population<T>::msp_subPop[k]->mp_pop[idxb];
                                        }
                                    }

                                }

                            }
                        break;
                        case Migration_Worst:
                            if(ms_mgrReplCondi){
                                 for(unsigned int k=0;k<Population<T>::msp_subPop.size();k++){
                                    if(Population<T>::msp_subPop[k]->m_evoNum%ms_mgrFre==0){
                                        int idxw=Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->findWorst();
                                        int idxb=Population<T>::msp_subPop[k]->findWorst();
                                        if(idxw!=-1&&idxb!=-1&&Population<T>::msp_subPop[k]->mp_pop[idxb]>Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->mp_pop[idxw]){
                                            Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->mp_pop[idxw]=Population<T>::msp_subPop[k]->mp_pop[idxb];
                                        }
                                    }

                                }

                            }else{
                                for(unsigned int k=0;k<Population<T>::msp_subPop.size();k++){
                                    if(Population<T>::msp_subPop[k]->m_evoNum%ms_mgrFre==0){
                                        int idxw=Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->findWorst();
                                        int idxb=Population<T>::msp_subPop[k]->findWorst();
                                        if(idxw!=-1&&idxb!=-1){
                                            Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->mp_pop[idxw]=Population<T>::msp_subPop[k]->mp_pop[idxb];
                                        }
                                    }

                                }

                            }
                        break;
                        case Migration_Random:
                            for(unsigned int k=0;k<Population<T>::msp_subPop.size();k++){
                                if(Population<T>::msp_subPop[k]->m_evoNum%ms_mgrFre==0){
                                    int num=Population<T>::msp_subPop[k]->m_popsize*ms_magnitude<Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->m_popsize*ms_magnitude?Population<T>::msp_subPop[k]->m_popsize*ms_magnitude:Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->m_popsize*ms_magnitude;
                                    if(num!=0){
                                            int *s,*t;
                                            s=new int[Population<T>::msp_subPop[k]->m_popsize]; t=new int[Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->m_popsize];
                                            gInitializeRandomArray(s,Population<T>::msp_subPop[k]->m_popsize);
                                            gInitializeRandomArray(t,Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->m_popsize);
                                            for(int j=0;j<num;j++){
                                                Population<T>::msp_subPop[(k+1)%Population<T>::msp_subPop.size()]->mp_pop[t[j]]=Population<T>::msp_subPop[k]->mp_pop[s[j]];
                                            }
											delete []s;delete[]t;

                                    }

                                }

                            }
                            
                        break;
                    }

                    break;
                    case Migration_Broadcast:
                    break;
                }

            }

        }
        static void setDefault(){
            ms_mgrFre=10;
            ms_magnitude=0.1;
            ms_isSynchronous=false;
            ms_mgrMode=Migration_Random;//Migration_Best;
            ms_mgrReplCondi=true;
            ms_mgrTopo=Migration_Ring;
        }
    protected:
    private:
};
template <typename T>
int Island<T>::ms_mgrFre;
template <typename T>
float Island<T>::ms_magnitude;
template <typename T>
bool Island<T>::ms_isSynchronous;
template <typename T>
MigrationMode Island<T>::ms_mgrMode;
template <typename T>
bool Island<T>::ms_mgrReplCondi;
template <typename T>
MigrationTopology Island<T>::ms_mgrTopo;
#endif // ISLAND_H
