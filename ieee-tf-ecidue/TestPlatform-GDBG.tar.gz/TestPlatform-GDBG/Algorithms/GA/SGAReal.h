/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 16 Nov 2011
// Last modified:
#ifndef SGAREAL_H
#define SGAREAL_H
#include "GAIndividual.h"
#include "GAPopulation.h"

class SGAReal:public GAPopulation<GAIndividual>
{
    public:
        SGAReal():GAPopulation<GAIndividual>() {}
        SGAReal(const int size, bool mode=true):GAPopulation<GAIndividual>(size,mode) {
            strcpy(ma_name,"simple real-coded GA");

            m_algPar<<"Population size: "<<m_popsize;
        }
        virtual ~SGAReal() {}
        int run(){
             while(!gIsTerminate()){
                //cout<<Global::g_runIdx<<" "<<m_best.getObj()<<endl;
                evolve();
            }
             return 0;
        }
    protected:
    private:
};

#endif // SGAREAL_H
