/*************************************************************************
* Project: Library of Evolutionary Algoriths
*************************************************************************
* Author: Changhe Li & Ming Yang
* Email: changhe.lw@google.com Or yangming0702@gmail.com
* Language: C++
*************************************************************************
*  This file is part of EAlib. This library is free software;
*  you can redistribute it and/or modify it under the terms of the
*  GNU General Public License as published by the Free Software
*  Foundation; either version 2, or (at your option) any later version.
*************************************************************************/
// Created: 12 Nov 2011
// Last modified:

#ifndef GAINDIVIDUAL_H
#define GAINDIVIDUAL_H

#include "../Individual.h"


class GAIndividual : public Individual
{
    public:
        GAIndividual();
        virtual ~GAIndividual();
        GAIndividual(const GAIndividual & other);
        GAIndividual&operator=(GAIndividual & rhs);

		void mutate(int low=0,int upper=Global::g_dimNumber);
		void xover(GAIndividual & mate,int low=0,int upper=Global::g_dimNumber);

        void setDistribution(double dis);
        void setMutationProbability(double p);
        void setXoverProbability(double p);
        void increaseDimension();
        void decreaseDimension();
		void setMutationStrategy(GAMutationStrategy s);
		void setMutationStep(double step);
    public:
        Chromosome m_backup;            // backup individual for p_self
        double m_fitness;               // fitness of each individual
        double m_distribution;          // distribution for mutation for real-coded encoding
        double m_mutationProb;          // mutation probability
        double m_xoverProb;             //crossover probability
		GAMutationStrategy m_mutationStratey;
		double m_mutationStep;			// mutation step in normal mutation strategy

        static int ms_numMutation;
        static int ms_numXover;
        bool m_flag;

    protected:
  
        void polynomialMutate(int rlower=0,int rupper=Global::g_dimNumber);
		void normalMutate(int rlower=0,int rupper=Global::g_dimNumber);
       
        void realXover(GAIndividual & mate);

        double getDelta(double u, double delta_l, double delta_u);

		//***********01.08.2013
		template<typename T>
		void singlePointXover(GAIndividual & mate, int rlower=0,int rupper=Global::g_dimNumber){
			if(Global::gp_uniformAlg->Next()>m_xoverProb) return;
			// single point crossover
			int p=gRandInt(rlower,rupper);

			for (int i = p; i < rupper; i++){
				if(m_pself.getGene(i).m_length==1||Global::gp_uniformAlg->Next()<=0.5){
					for(unsigned int j=0;j<m_pself.getGene(i).m_length;j++){
						T x;
						x=m_pself.getGene<T>(i,j);
						m_pself.getGene<T>(i,j)=mate.m_pself.getGene<T>(i,j);
						mate.m_pself.getGene<T>(i,j)=x;
					}  
				}
			}
		}
		template<typename T>
		 void combinatorialMutate(int rlower=0,int rupper=Global::g_dimNumber){
		    for (int i = rlower; i <rupper; i++){
				for(unsigned int j=0;j<m_pself.getGene(i).m_length;j++){
					if(Global::gp_uniformAlg->Next()<=m_mutationProb){
						ms_numMutation++;
						T l,u;
						Global::gp_problem->getSearchRange<T>(l,u,i);
						T x;
						// assume the search range is continuous in integer space
						float f=u-l;
						f=f*Global::gp_uniformAlg->Next();
						if(f-floor(f)>=0.5) f=floor(f)+1;
						else f=floor(f);

						x=l+(T)f;

						if(m_pself.getGene<T>(i,j)==x) {
							if(x+1>u) x=x-1;
							else x=x+1;
						}
					
						m_pself.getGene<T>(i,j)=x;
					}
				}
			}
		}


    private:
};

#endif // GAINDIVIDUAL_H
