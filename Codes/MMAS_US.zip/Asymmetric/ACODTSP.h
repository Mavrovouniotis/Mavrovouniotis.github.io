extern double **traffic_factors;
extern int problem_size;
